# Setup file for package pm_tools

from setuptools import setup

setup(name='pm_tools',
      version='0.3',
      description='Project Management Metrics',
      packages=['pm_tools'],
      author = "Plamen Rabadzhiyski",
      author_email = "plamen@pmtonomy.com",
      zip_safe=False)
